CodeIgniter: Add, Edit, Delete, View with Login &amp; Registration – MVC CRUD Application
========

A simple and basic CRUD application with login and registration feature using CodeIgniter PHP Framework.

Blog Article: [CodeIgniter: Add, Edit, Delete, View with Login & Registration – MVC CRUD Application](http://blog.chapagain.com.np/codeigniter-add-edit-delete-view-with-login-registration-mvc-crud-application/)
